## O que muda

<!-- Descreva em uma ou duas frases. -->

## Requisitos e regras atendidos

- RF:
- RN:

## Como testar

1.
2.

## Checklist

- [ ] Branch criada a partir de `develop` no formato `feature/nome-da-funcionalidade`
- [ ] Commits seguem o padrão semântico (`feat`, `fix`, `docs`, `refactor`, `test`)
- [ ] `pytest` passa localmente
- [ ] Regra de negócio nova tem teste correspondente (RNF06)
- [ ] Revisado por um integrante que não é o autor
