---
name: Relatar um problema
about: Comportamento diferente do esperado
labels: bug
---

**O que aconteceu**

**O que deveria acontecer**

**Como reproduzir**
1.
2.

**Requisito ou regra afetada** (RF / RN)
