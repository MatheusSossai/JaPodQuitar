---
name: Nova funcionalidade
about: User story de uma sprint
labels: feature
---

**User story**
Como <perfil> eu quero <ação> PARA QUE <benefício>.

**Requisito atendido** (RF)

**Dor atendida** (D1 a D7)

**Critérios de aceite**
- [ ]
